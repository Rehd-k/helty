import 'package:auto_route/auto_route.dart';
import 'package:data_table_2/data_table_2.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:helty/src/accounts/accounts_palette.dart';
import 'package:helty/src/accounts/auth/accounting_permissions.dart';
import 'package:helty/src/accounts/providers/accounts_providers.dart';
import 'package:helty/src/accounts/widgets/accounts_access_denied.dart';
import 'package:helty/src/accounts/widgets/accounts_async_scaffold.dart';
import 'package:helty/src/accounts/widgets/accounts_data_table_box.dart';
import 'package:helty/src/accounts/widgets/accounts_money_format.dart';
import 'package:helty/src/accounts/widgets/accounts_period_selector.dart';
import 'package:helty/src/providers/auth_provider.dart';

@RoutePage()
class AccountsPeriodComparisonScreen extends ConsumerWidget {
  const AccountsPeriodComparisonScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    if (!canViewProfitLoss(ref.watch(authProvider).staff)) {
      return const AccountsAccessDenied(title: 'Period comparison');
    }
    final async = ref.watch(accountsPeriodComparisonProvider);
    final fmt = accountsNairaFormat();

    return AccountsAsyncScaffold(
      title: 'Period comparison',
      subtitle: 'Month-over-month and year-over-year',
      colors: AccountsPalette.reports,
      asyncValue: async,
      header: const AccountsPeriodSelector(),
      onRetry: () => ref.invalidate(accountsPeriodComparisonProvider),
      builder: (context, points) {
        if (points.isEmpty) {
          return const AccountsEmptyState(title: 'No Period comparison', subtitle: 'No records for the selected filters.');
        }
        return AccountsDataTableBox(
          child: DataTable2(
            columns: const [
              DataColumn2(label: Text('Metric'), size: ColumnSize.L),
              DataColumn2(label: Text('Current'), size: ColumnSize.S),
              DataColumn2(label: Text('Previous'), size: ColumnSize.S),
              DataColumn2(label: Text('Change %'), size: ColumnSize.S),
            ],
            rows: [
              for (final p in points)
                DataRow2(
                  cells: [
                    DataCell(Text(p.label)),
                    DataCell(Text(fmt.format(p.current))),
                    DataCell(Text(fmt.format(p.previous))),
                    DataCell(Text('${p.percentChange.toStringAsFixed(1)}%')),
                  ],
                ),
            ],
          ),
        );
      },
    );
  }
}
